
VdotH2O_nSI     = 5;                        % [mL/min]
VdotH2O         = VdotH2O_nSI*(10^-6)/60;   % [m3/s]

c_IrAWL       	= 0.1;  % [mol/m3]

F_IrAWL         = VdotH2O*c_IrAWL;      % [mol/s]

F_IrAWL