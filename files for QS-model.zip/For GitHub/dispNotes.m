

%% go through all notes and display

if exist('note')
    fields = fieldnames(note);
    for i = 1:numel(fields)
        disp(['*** ', note.(fields{i}), ' ***']);
    end
else
  	disp(['*** No notes have been created ***']);
end