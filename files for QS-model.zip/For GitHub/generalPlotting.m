fig1 = figure('Name', 'Name');
    set(gcf,'color','w');
    set(fig1, 'units', 'points', 'position', [fig.x0, fig.y0, fig.width, fig.height]);

    subplot(2,3,1)               
        plot(, '-', 'LineWidth', 1.5);      
%         hold on;
%         plot(); 
        
%         xlim([)]);


        h = legend('Mig. (n=1)');
        rect = [0.22, 0.66, 0, 0];                              % [posX, posY, width, height]
        set(h, 'Position', rect);
%         xlabel('');
%         ylabel(['']);
        pbaspect([1 1 1]);
        box on; ax = gca; ax.LineWidth = 1;