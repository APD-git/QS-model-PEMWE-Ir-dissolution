%             experimental data                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% mpa = mass per area [ug/cm2]

%% cations in AWL data

% CP cation data
 
    eCP.absFraBoT     	= 0.32;         % [-]
    eCP.absFraMoT       = 0.225;    
    eCP.absFraEoT       = 0;
    
    eCP.cIrBoT          = 3.3E-6;      	% [mol/m3]
    eCP.cIrMoT          = 7.0E-6;       % [mol/m3]
    eCP.cIrEoT          = 5.9E-6;       % [mol/m3]
    
    eCP.cIrCatBoT     	= eCP.cIrBoT*eCP.absFraBoT;      	% [mol/m3]
    eCP.cIrCatMoT    	= eCP.cIrMoT*eCP.absFraMoT;         % [mol/m3]
    eCP.cIrCatEoT     	= eCP.cIrEoT*eCP.absFraEoT;         % [mol/m3]
    
    eCP.cIrAniAWL_BoT     	= eCP.cIrBoT*(1-eCP.absFraBoT);      	% [mol/m3]
    eCP.cIrAniAWL_MoT    	= eCP.cIrMoT*(1-eCP.absFraMoT);         % [mol/m3]
    eCP.cIrAniAWL_EoT     	= eCP.cIrEoT*(1-eCP.absFraEoT);         % [mol/m3]
      
    eCP.t_nSI_BoT       = 17;            % [h] BoT for abs. test
    eCP.t_nSI_MoT       = 86;
    eCP.t_nSI_EoT       = 166.7;
    
% 1.3 V cation data

    e13.absFraBoT     	= 0.54;         % [-]
    e13.absFraMoT       = 0.13;    
    e13.absFraEoT       = 0.025;
    
    e13.cIrBoT          = 1.7E-5;         % [mol/m3]
    e13.cIrMoT          = 4.15E-5;       % [mol/m3]
    e13.cIrEoT          = 4.3E-5;       % [mol/m3]
    
    e13.cIrCatBoT     	= e13.cIrBoT*e13.absFraBoT;      	% [mol/m3]
    e13.cIrCatMoT    	= e13.cIrMoT*e13.absFraMoT;         % [mol/m3]
    e13.cIrCatEoT     	= e13.cIrEoT*e13.absFraEoT;         % [mol/m3]
    
    e13.cIrAniAWL_BoT     	= e13.cIrBoT*(1-e13.absFraBoT);      	% [mol/m3]
    e13.cIrAniAWL_MoT    	= e13.cIrMoT*(1-e13.absFraMoT);         % [mol/m3]
    e13.cIrAniAWL_EoT     	= e13.cIrEoT*(1-e13.absFraEoT);         % [mol/m3]
    
    e13.t_nSI_BoT       = 7;            % [h] BoT for abs. test
    e13.t_nSI_MoT       = 86;
    e13.t_nSI_EoT       = 166.7;
    
% 0 V cation data

    e0V.absFraBoT     	= 0.68;         % [-]
    e0V.absFraMoT       = 0.125;    
    e0V.absFraEoT       = 0.05;
    
    e0V.cIrBoT          = 1.84E-6;         % [mol/m3]
    e0V.cIrMoT          = 7.4E-6;       % [mol/m3]
    e0V.cIrEoT          = 5.5E-6;       % [mol/m3]
    
    e0V.cIrCatBoT     	= e0V.cIrBoT*e0V.absFraBoT;      	% [mol/m3]
    e0V.cIrCatMoT    	= e0V.cIrMoT*e0V.absFraMoT;         % [mol/m3]
    e0V.cIrCatEoT     	= e0V.cIrEoT*e0V.absFraEoT;         % [mol/m3]
    
    e0V.t_nSI_BoT       = 1;            % [h] BoT for abs. test
    e0V.t_nSI_MoT       = 86;
    e0V.t_nSI_EoT       = 166.7;
    
%% cations in CWL data

% CP cation and anion data

    eCP.CWLabsCatFraBoT  	= 0.29;         % [-]
    eCP.CWLabsCatFraMoT    = 0.165;    
    eCP.CWLabsCatFraEoT    = 0.89;
    
    eCP.mpaCWL_BoTnSI  	= 0.135;      	% [ug/cm2]                          % mpa = mass per area [ug/cm2]
    eCP.mpaCWL_MoTnSI 	= 0.23;         % [ug/cm2]
    eCP.mpaCWL_EoTnSI  	= 0.258;        % [ug/cm2]

    eCP2.mpaCWL1_nSI    = 0.18;         % [ug/cm2] 4 h experiment. Info from meeting with MM
    eCP2.t_mpaCWL1_nSI	= 24;           % [h]  

    eCP.tCWL_nSI_BoT       = 1;            % [h]
    eCP.tCWL_nSI_MoT       = 86;
    eCP.tCWL_nSI_EoT       = 166.7;
    
    eCP.flCWL_BoT       = 2.8E-10;           % [mol/(m2*s)]
    eCP.flCWL_MoT       = 6E-12;          % [mol/(m2*s)]
    eCP.flCWL_EoT       = 3.3E-12;          % [mol/(m2*s)]
    
    eCP.flAniCWL_BoT       = eCP.flCWL_BoT*(1-eCP.CWLabsCatFraBoT);       % [mol/(m2*s)]
    eCP.flAniCWL_MoT       = eCP.flCWL_MoT*(1-eCP.CWLabsCatFraMoT);       % [mol/(m2*s)]
    eCP.flAniCWL_EoT       = eCP.flCWL_EoT*(1-eCP.CWLabsCatFraEoT);       % [mol/(m2*s)]
    
    eCP.flCatCWL_BoT       = eCP.flCWL_BoT*eCP.CWLabsCatFraBoT;       % [mol/(m2*s)]
    eCP.flCatCWL_MoT       = eCP.flCWL_MoT*eCP.CWLabsCatFraMoT;       % [mol/(m2*s)]
    eCP.flCatCWL_EoT       = eCP.flCWL_EoT*eCP.CWLabsCatFraEoT;       % [mol/(m2*s)]

% e13 cation and anion data

    e13.CWLabsCatFraBoT 	= 0.28;         % [-]
    e13.CWLabsCatFraMoT     = 0.165;    
    e13.CWLabsCatFraEoT     = 0.89;
    
    e13.mpaCWL_BoTnSI  	= 0.135;      	% [ug/cm2] total accumulated amount
    e13.mpaCWL_MoTnSI 	= 0.23;         % [ug/cm2]
    e13.mpaCWL_EoTnSI  	= 0.258;        % [ug/cm2]
    
    
    e13.tCWL_nSI_BoT       = 1;            % [h]
    e13.tCWL_nSI_MoT       = 86;
    e13.tCWL_nSI_EoT       = 166.7;
    
    e13.flCWL_BoT       = 3E-10;               % [mol/(m2*s)]
    e13.flCWL_MoT       = 3.3E-12;              % [mol/(m2*s)]
    e13.flCWL_EoT       = 6.0E-12;               % [mol/(m2*s)]
    
    e13.flAniCWL_BoT       = e13.flCWL_BoT*(1-e13.CWLabsCatFraBoT);       % [mol/(m2*s)]
    e13.flAniCWL_MoT       = e13.flCWL_MoT*(1-e13.CWLabsCatFraBoT);       % [mol/(m2*s)]
    e13.flAniCWL_EoT       = e13.flCWL_EoT*(1-e13.CWLabsCatFraEoT);       % [mol/(m2*s)]
    
    e13.flCatCWL_BoT       = e13.flCWL_BoT*e13.CWLabsCatFraBoT;       % [mol/(m2*s)]
    e13.flCatCWL_MoT       = e13.flCWL_MoT*e13.CWLabsCatFraBoT;       % [mol/(m2*s)]
    e13.flCatCWL_EoT       = e13.flCWL_EoT*e13.CWLabsCatFraEoT;       % [mol/(m2*s)]

% 0V cation amd anion data
    e0V.CWLabsCatFraBoT 	= 0.28;         % [-]
    e0V.CWLabsCatFraMoT     = 0.015;    
    e0V.CWLabsCatFraEoT     = 0.58;
    
    e0V.flCWL_BoT       = 6.5E-10;               % [mol/(m2*s)]
    e0V.flCWL_MoT       = 1.1E-11;              % [mol/(m2*s)]
    e0V.flCWL_EoT       = 3.6E-13;               % [mol/(m2*s)]
    
    e0V.flAniCWL_BoT       = e0V.flCWL_BoT*(1-e0V.CWLabsCatFraBoT);       % [mol/(m2*s)]
    e0V.flAniCWL_MoT       = e0V.flCWL_MoT*(1-e0V.CWLabsCatFraBoT);       % [mol/(m2*s)]
    e0V.flAniCWL_EoT       = e0V.flCWL_EoT*(1-e0V.CWLabsCatFraEoT);       % [mol/(m2*s)]
    
    e0V.flCatCWL_BoT       = e0V.flCWL_BoT*e0V.CWLabsCatFraBoT;       % [mol/(m2*s)]
    e0V.flCatCWL_MoT       = e0V.flCWL_MoT*e0V.CWLabsCatFraBoT;       % [mol/(m2*s)]
    e0V.flCatCWL_EoT       = e0V.flCWL_EoT*e0V.CWLabsCatFraEoT;       % [mol/(m2*s)]

%% amounts in AWL, CCL, CWL
    
    eCP.t_sa_nSI        = xlsread('dissDataAWL.xlsx', 'MM CP', 'D5:D12');    	% [h] sampling times
    eCP.c_Ir            = xlsread('dissDataAWL.xlsx', 'MM CP', 'H5:H12');    	% [mol/m3]
    eCP.mPerA_nSI       = xlsread('dataCCM.xlsx', 'CCL', 'L5:L6');          	% [ug/cm2]
    eCP.t_CCL           = xlsread('dataCCM.xlsx', 'CCL', 'K5:K6');           	% [s]
    eCP.mCWLperA_nSI    = xlsread('dissDataCWL.xlsx', 'CP', 'E5:E12');      	% [ug/cm2]
    eCP.t_CWL           = xlsread('dissDataCWL.xlsx', 'CP', 'C23:C30');      	% [ug/cm2]
    eCP.flCWL           = xlsread('dissDataCWL.xlsx', 'CP', 'I23:I30');      	% [mol/(m2*s)]
    eCP.mAWLperA_nSI    = mol_ugPerCm2(p.V*eCP.c_Ir, p);                        % [ug/cm2]

    eCP.mpaCatAWL_BoT    = mol_ugPerCm2(p.V*eCP.cIrCatBoT, p);      
    eCP.mpaCatAWL_MoT    = mol_ugPerCm2(p.V*eCP.cIrCatMoT, p); 
    eCP.mpaCatAWL_EoT    = mol_ugPerCm2(p.V*eCP.cIrCatEoT, p); 
    
    eCP.mAniAWLperA_BoT_nSI    = mol_ugPerCm2(p.V*eCP.cIrAniAWL_BoT, p);      
    eCP.mAniAWLperA_MoT_nSI    = mol_ugPerCm2(p.V*eCP.cIrAniAWL_MoT, p); 
    eCP.mAniAWLperA_EoT_nSI    = mol_ugPerCm2(p.V*eCP.cIrAniAWL_EoT, p); 
    
    e0V.mPerA_nSI       = xlsread('dataCCM.xlsx', 'CCLnew', 'D5:D11');      	% [ug/cm2]
    e0V.t_CCL           = xlsread('dataCCM.xlsx', 'CCLnew', 'C5:C11');        	% [s]
    e0V.mCWLperA_nSI    = xlsread('dissDataCWL.xlsx', '0V', 'E5:E13');      	% [ug/cm2]
    e0V.t_CWL           = xlsread('dissDataCWL.xlsx', '0V', 'C23:C31');      	% [ug/cm2]
    e0V.cIrAWL        	= xlsread('dissDataAWL.xlsx', 'MM 0V', 'H5:H19');     	% [mol/m3]
    e0V.tAWL_nSI        = xlsread('dissDataAWL.xlsx', 'MM 0V', 'D5:D19');    	% [h] sampling times (without CS)
    e0V.flCWL           = xlsread('dissDataCWL.xlsx', '0V', 'I23:I31');      	% [mol/(m2*s)]
    e0V.mAWLperA_nSI    = mol_ugPerCm2(p.V*e0V.cIrAWL, p);                      % [ug/cm2]
    
    e0V.mpaCatAWL_BoT    = mol_ugPerCm2(p.V*e0V.cIrCatBoT, p);      
    e0V.mpaCatAWL_MoT    = mol_ugPerCm2(p.V*e0V.cIrCatMoT, p); 
    e0V.mpaCatAWL_EoT    = mol_ugPerCm2(p.V*e0V.cIrCatEoT, p);
    
    e13.t_sa_nSI        = xlsread('dissDataAWL.xlsx', 'MM1.3V', 'D6:D15');    	% [h] sampling times
    e13.c_Ir            = xlsread('dissDataAWL.xlsx', 'MM1.3V', 'H6:H15');     	% [mol/m3]
    e13.mPerA_nSI       = xlsread('dataCCM.xlsx', 'CCLnew', 'H5:H6');        	% [ug/cm2]
    e13.t_CCL           = xlsread('dataCCM.xlsx', 'CCLnew', 'G5:G6');       	% [s]
    e13.mCWLperA_nSI    = xlsread('dissDataCWL.xlsx', '1.3V', 'E5:E13');      	% [ug/cm2]
    e13.t_CWL           = xlsread('dissDataCWL.xlsx', '1.3V', 'C23:C31');      	% [ug/cm2]
    e13.flCWL           = xlsread('dissDataCWL.xlsx', '1.3V', 'I23:I31');      	% [mol/(m2*s)]
    e13.mAWLperA_nSI    = mol_ugPerCm2(p.V*e13.c_Ir, p);                        % [ug/cm2]
    
    e13.mpaCatAWL_BoT    = mol_ugPerCm2(p.V*e13.cIrCatBoT, p);      
    e13.mpaCatAWL_MoT    = mol_ugPerCm2(p.V*e13.cIrCatMoT, p); 
    e13.mpaCatAWL_EoT    = mol_ugPerCm2(p.V*e13.cIrCatEoT, p);
    
    e13.mAniAWLperA_BoT_nSI    = mol_ugPerCm2(p.V*e13.cIrAniAWL_BoT, p);      
    e13.mAniAWLperA_MoT_nSI    = mol_ugPerCm2(p.V*e13.cIrAniAWL_MoT, p); 
    e13.mAniAWLperA_EoT_nSI    = mol_ugPerCm2(p.V*e13.cIrAniAWL_EoT, p); 
    
%% Initial AWL flux (initial slope)

    eCP.Del_x = 50; eCP.Del_y = 6E-6; 
    e13.Del_x = 10; e13.Del_y = 3E-5; 
    e0V.Del_x = 30; e0V.Del_y = 3E-5; 

    eCP.mInit = eCP.Del_y/eCP.Del_x/3600;            % [mol/(m2*s)]
    e13.mInit = e13.Del_y/e13.Del_x/3600;
    e0V.mInit = e0V.Del_y/e0V.Del_x/3600;

    