%               model parameters                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% no.2
% mpa: mass per area [ug/cm2]

%% general model parameters 

    A_nSI           = 5;                    % [cm2]
    p.A             = A_nSI*10^-4;          % [m2]
    p.zHp           = 1;

    p.xCathDirAWL  	= 0.07;                 % fraction of Ir cations into AWL direction
    p.xDirCath      = 1 - p.xCathDirAWL;  	% fraction of total dyn-diss going to direction cathode side (following direction fractions of JES cations)
    
    p.xCatAWL       = 0.25;                 % [-] cationic fraction of the flux going to AWL direction
    p.xAniAWL       = 1 - p.xCatAWL;        % [-] anionic fraction of the flux going to AWL direction
    p.z_O2          = 4;                    % [-]
    p.nDrag         = 2;                    % [-]

    cd_nSI          = 1;                    % [A/cm2]
    p.cd          	= cd_nSI*10000;         % [A/m2]
    t_tot           = 500*20*60;            % [s]
    
    p.nDotO2perA    = p.cd/(p.F*4);             % [mol/(m2*s)] oxygen evolution rate per area during on-phase
    p.nDotO2        = p.nDotO2perA*p.A;         % [mol/s]
    V_nSI           = 0.75;                     % [L]
    p.V             = V_nSI/1000;               % [m3]
    pAD.kDepAni   	= 3.3E-7;                   % [m/s] value from Dam 2024 for comparison
    VdotH2O_nSI     = 5;                        % [mL/min] flow rate (for comparing Ir recirc. flow and Ir diss. flow)
    VdotH2O         = VdotH2O_nSI*(10^-6)/60;   % [m3/s]

% sensitivity analysis Ir band params
    SA_a = 1;   % 2
    SA_b = 1;   % 10
    SA_c = 1;   % 2

%% parameters cp model

    mCP.Acat         	= 3.4548e-8;                % [mol/(m2*s)]
    mCP.Aani            = 8.8442e-11;               % [mol/(m2*s)]
    mCP.Ccat          	= 2.61E-4;                  % [1/s] stab. param. cat. (dyn. diss. decline speed) (MS: "B")
    mCP.Cani          	= 2.1E-6;                   % [1/s] stab. param. ani.
    mCP.kBackAni      	= 7.5E-6;                 	% [m/s] 7E-5 
    mCP.kBackCat        = 5E-4;                    	% [m/s] back transport speed of cations from AWL to CCM
    mCP.IB_a          	= SA_a*5.7E+6;           	% [1/mol] Ir band form. param.
    mCP.IB_b          	= SA_b*8E-9;             	% [mol] Ir band form. param.
    mCP.probCWL         = 0.04;                     % [-] probability of leaving to CWL
    mCP.IB_c            = SA_c*0.35;             	% [-] Probability blocked "before transition" of sig. fun. (MS: "Th_bl,bt")
    
    mCP.expon          	= 1.0;                     	% diss. stab. param. cat.
    mCP.onFrac          = 1;                      	% [-] fraction of time where OER is "on" 
   
%% parameters 1.3 V AST simulation

    m13.Acat         	= 4.3184e-08;               % [mol/(m2*s)]
    m13.Aani            = 9.8365e-10;               % [mol/(m2*s)]
    m13.Ccat           	= 4.9E-4;                   % [1/s] stab. param. cat.
    m13.Cani           	= 5.93E-6;                	% [1/s] stab. param. ani.
    m13.IB_a          	= SA_a*2.4E+7;            	% [1/mol] higher a -> faster transition
    m13.IB_b          	= SA_b*3.5E-10;          	% [mol] 
    m13.kBackAni     	= 2.9E-6;                 	% [m/s] "apparent" average off/on phase
    m13.kBackCat        = 8.0E-6;                	% [m/s] back transport speed of cations from AWL to CCM
    m13.probCWL         = 0.23;                  	% [-] probability of leaving to CWL
    m13.IB_c            = getThBl0(mCP.IB_c, mCP.IB_a, mCP.IB_b, m13.IB_a, m13.IB_b);   % idea: ThBlock(t=0) should be identical for different ASTs

    m13.onFrac          = 0.5;                      	% [-] fraction of time where OER is "on"
    m13.expon          	= 1.0;                       	% diss. stab. param. cat.
    
%% parameters 0 V AST simulation

    m0V.Acat           	= 1.0364e-08;                   % [mol/(m2*s)]
    m0V.Aani            = 8.2050e-10;                   % [mol/(m2*s)]
    m0V.Ccat           	= 7.125E-5;                  	% [1/s] stab. param. cat.
    m0V.Cani           	= 3E-6;                     	% [1/s] stab. param. ani.
    
    m0V.IB_a        	= SA_a*2.1E+7;              	% [1/mol] higher a -> faster transition
    m0V.IB_b         	= SA_b*4.7E-10;                	% [mol]
    m0V.kBackCat        = 3.0E-4;                     	% [m/s] back transport speed of cations from AWL to CCM
    m0V.kBackAni     	= 4E-5;                      	% [m/s] "apparent" average off/on phase
    m0V.probCWL         = 0.08;                      	% [-] probability of leaving to CWL
    
    m0V.onFrac          = 0.5;                       	% [-] fraction of time where OER is "on"
    m0V.expon          	= 1.0;                        	% diss. stab. param. cat.
    m0V.IB_c            = getThBl0(mCP.IB_c, mCP.IB_a, mCP.IB_b, m0V.IB_a, m0V.IB_b);     % idea: ThBlock(t=0) should be identical for different ASTs
    
%% get parameters for leaving probability CCL vs CWL

%     getParLB;
    
%% paramters for CCL/CWL "leaving probability" calculation 

    % CCL
    mCP.lp_A_CCL = 1.17; mCP.lp_B_CCL = 1/6;
    m13.lp_A_CCL = 0.13; m13.lp_B_CCL = 1/3;
    m0V.lp_A_CCL = 0.08; m0V.lp_B_CCL = 1/2;
    
    % CWL
    mCP.lp_A_CWL = 0.285; mCP.lp_B_CWL = 1/12;
    m13.lp_A_CWL = 0.150; m13.lp_B_CWL = 1/12;
    m0V.lp_A_CWL = 0.110; m0V.lp_B_CWL = 1/6;
    
    mCP.lp0 = 0.12;
    m13.lp0 = 0.24;
    m0V.lp0 = 0.33;
