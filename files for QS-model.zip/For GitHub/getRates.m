function [diRateAniAWL, diRateCatAWL, diRateCatIP, R_bf, ThBlo, RbackTrAni, RbackTrCat, F_CWL, FtoCath, RdepCCL, FconvAni, lp]...
    = getRates(t, p, nBa, cIrAniAWL, cIrCatAWL, mo)
% get rates

    diRateCat    = mo.onFrac*p.A*mo.Acat./(1 + mo.Ccat*t.^mo.expon);  	% [mol/s] averaged
    diRateAni    = mo.onFrac*p.A*mo.Aani./(1 + mo.Cani*t.^mo.expon);    % [mol/s] averaged value
    
    diRateAniAWL  	= diRateAni;            	% [mol/s] transport rate of diss. Ir anions into AWL
    diRateCatAWL   	= diRateCat*p.xCathDirAWL ;     % [mol/s] transport rate of diss. Ir cations into AWL
    diRateCatIP     = diRateCat*p.xDirCath;     % [mol/s] membrane direction ("IP": ionomer phase)
    
    ThBlo           = sigmo(nBa, mo);                           % [-] blocking probability via sigmoidal function
    R_bf            = ThBlo.*diRateCatIP;                   	% [mol/s] rate going into band formation
    RbackTrAni      = p.A*mo.kBackAni*cIrAniAWL;             	% [mol/s]
    RbackTrCat      = p.A*mo.kBackCat*cIrCatAWL;              	% [mol/s]

    lp          = mo.probCWL;                 	% [-] probability of leaving from CCL into CWL
    FtoCath     = diRateCatIP - R_bf;           % [mol/s]
    F_CWL       = FtoCath*lp;                   % [mol/s]
    RdepCCL     = FtoCath*(1-lp);               % [mol/s]

    FconvAni 	= p.A*(p.cd/(1*p.F))*p.nDrag*(p.M_H2O/p.rho_H2O)*cIrAniAWL;        % [mol/s]

end

