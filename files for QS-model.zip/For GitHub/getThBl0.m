function [ThBl0_i] = getThBl0(ThBl0_CP, aCP, bCP, a_i, b_i)
% used in "getPar.m"
% idea: ThBlock(t=0) should be identical for different ASTs

    denom       = 1 - 1/(   1 + exp(a_i*b_i)   );
    nom         = ThBl0_CP + (1-ThBl0_CP)*(  1/(1 + exp(aCP*bCP))  ) - 1/(  1 + exp(a_i*b_i)  );
    ThBl0_i     = nom / denom;
end

