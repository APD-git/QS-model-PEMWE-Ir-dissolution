function [dxdt] = modelSystem(t, p, x, mo)
% 'mo' = mode of AST (cp, 1.3V, 0V)    

    cIrAniAWL	= x(1);         % [mol/m3] conc. anions in AWL
    nCCL        = x(2);         % [mol] amount in CCL
    nBa         = x(3);         % [mol] amount in Ir band
    nBackTr     = x(4);         % [mol] amount back-transported from AWL to CCM
    nCWL        = x(5);         % [mol] amount in CWL
    cIrCatAWL 	= x(6);         % [mol/m3] conc. anions in AWL 
    
    [diRateAniWL, diRateCatWL, diRateCatIP, R_bf, ThBlo, RbackTrAni, RbackTrCat, F_CWL, FtoCath, RdepCCL, FconvAni] ...
        = getRates(t, p, nBa, cIrAniAWL, cIrCatAWL, mo);
    
    dcAni_ov_dt	= (1/p.V)*(   diRateAniWL - RbackTrAni   );   	% [mol/(m3*s)] ODE Ir anions in AWL
    dcCat_ov_dt = (1/p.V)*(   diRateCatWL - RbackTrCat   );  	% [mol/(m3*s)] ODE Ir cations in AWL
    dnCCL_ov_dt = RdepCCL;                                      % [mol] ODE Ir deposited in CCL
    dnBa_ov_dt	= R_bf;                  	% [mol] ODE Ir deposited in Ir band
    dnBackTrAni	= RbackTrAni;           	% [mol] ODE Ir deposited from AWL back into ACL
    dnCWL_ov_dt = F_CWL;                 	% [mol] ODE amount of Ir which left via CWL
    
    dxdt = [dcAni_ov_dt; dnCCL_ov_dt; dnBa_ov_dt; dnBackTrAni; dnCWL_ov_dt; dcCat_ov_dt];
end
