function [mPerA_nSI] = mol_ugPerCm2(n, p)
% recalculate from molar amount "n" [mol] to mass per area "mPerA_nSI" [ug/cm2] 

    nPerA       = n/p.A;                        % [mol/m2]
    mPerA_nSI   = nPerA*p.M_Ir*10^9/10000;      % [ug/cm2]
end

