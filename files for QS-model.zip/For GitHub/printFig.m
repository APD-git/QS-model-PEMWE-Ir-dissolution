function [] = printFig(fig)
% save a figure on the desktop

    savedFolderPath = pwd;
    cd 'C:\Users\an_ph\Desktop'
    exportgraphics(fig,"newFigure.png");
    cd(savedFolderPath);
end

