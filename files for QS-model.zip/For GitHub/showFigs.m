%% show figures

    niceGruen = '#3adf1d';
    niceRed = '#d30000';
    fig.x0 = 5; fig.y0 = 35; fig.width = 830; fig.height = 460;

%%
    fig1 = figure('Name', 'Params & band & SI units');
        set(gcf, 'color', 'w');
        set(fig1, 'units', 'points', 'position', [fig.x0, fig.y0, fig.width, fig.height]);

            subplot(2,3,4)
                plot(mCP.tSol/3600, mCP.mpaDiBa_nSI, '--', 'LineWidth', 1, 'Color', niceGruen);
                hold on;
                plot(mCP.tSol/3600, mCP.mpaDiBa_nSI/2, '-', 'LineWidth', 1, 'Color', niceGruen);
                plot(m13.tSol/3600, m13.mpaDiBa_nSI, '-', 'LineWidth', 1, 'Color', 'b');
                plot(m0V.tSol/3600, m0V.mpaDiBa_nSI, '-', 'LineWidth', 1, 'Color', niceRed);
                pbaspect([1 1 1]);
                box on; ax = gca; ax.LineWidth = 1;
                set(gca, 'TickLength', [0.015, 0.01]);
                xlabel('Time [h]');
                ylabel('Amount in Ir band [\mug/cm^2]');
                h = legend('CP', 'CP/2', '1.3V', '0 V', 'location', 'southeast', 'LineWidth', 0.5);
                h.ItemTokenSize = [15 15];

                
            subplot(2,3,5)     
                plot(mCP.mpaDiBaVec_nSI, mCP.ThBlTheo, '--', 'LineWidth', 1, 'Color', 'black'); hold on;
                plot(mCP.mpaDiBa_nSI, mCP.ThBl, '-', 'LineWidth', 1.5, 'Color', niceGruen);
                plot(m13.mpaDiBaVec_nSI, m13.ThBlTheo, '--', 'LineWidth', 1, 'Color', 'black');
                plot(m13.mpaDiBa_nSI, m13.ThBl, '-', 'LineWidth', 1.5, 'Color', 'b');
                plot(m0V.mpaDiBaVec_nSI, m0V.ThBlTheo, '--', 'LineWidth', 1, 'Color', 'black');
                plot(m0V.mpaDiBa_nSI, m0V.ThBl, '-.', 'LineWidth', 1.5, 'Color', niceRed);
                h = legend('', 'CP', '', '1.3V', '', '0 V', 'Position', [0.57 0.288824 0 0], 'LineWidth', 0.5);
                h.ItemTokenSize = [15 15];
                xlabel('Ir amount in band [\mug/cm^2]');
                ylabel('Probability \Theta_{bl} [-]');
                xlim([0, 15]);
                pbaspect([1 1 1]);
%                 title('Band formation correlation');
                box on; ax = gca; ax.LineWidth = 1;
                set(gca, 'TickLength', [0.015, 0.01]);
                ytickformat('%.2f');
                annotation(fig1, 'textbox', [0.44 0.48 0.154 0.0358],...
                'String',{'Band formation correlation'}, 'FitBoxToText', 'off');

            subplot(2,3,6)
                plot(mCP.tSol/3600, mCP.ThBl, '-', 'LineWidth', 1, 'Color', niceGruen);
                hold on;
                plot(m13.tSol/3600, m13.ThBl, '-', 'LineWidth', 1, 'Color', 'b');
                plot(m0V.tSol/3600, m0V.ThBl, '-', 'LineWidth', 1, 'Color', niceRed);
                h = legend('CP', '1.3V', '0 V', 'Position', [0.93 0.288824 0 0], 'LineWidth', 0.5);
                h.ItemTokenSize = [15 15];
                xlabel('Time [h]');
                ylabel('Probability \Theta_{bl} [-]');
                pbaspect([1 1 1]);
                box on; ax = gca; ax.LineWidth = 1;
                set(gca, 'TickLength', [0.015, 0.01]);
                ytickformat('%.2f');
                ylim([0.6, 1]);



%%
    fig2 = figure('Name', 'Amounts and CWL-flux over t');
        set(gcf, 'color', 'w');
        set(fig2, 'units', 'points', 'position', [fig.x0, fig.y0, fig.width, fig.height]);
        
        subplot(2,3,1)
            plot(mCP.tSol/3600, mCP.mpaBaTr_nSI, '-', 'LineWidth', 1, 'Color', niceGruen);
            hold on;
            plot(m13.tSol/3600, m13.mpaBaTr_nSI, '-', 'LineWidth', 1, 'Color', 'b');
            plot(m0V.tSol/3600, m0V.mpaBaTr_nSI, '-', 'LineWidth', 1, 'Color', niceRed);
            h = legend('CP', '1.3V', '0 V', 'location', 'northwest', 'LineWidth', 0.5);
            h.ItemTokenSize = [15 15];
            xlabel('Time [h]');
            ylabel('Ani amount back-tr. [ug/cm^2]');
            pbaspect([1 1 1]);
            box on; ax = gca; ax.LineWidth = 1;
            set(gca, 'TickLength', [0.015, 0.01]);
            ytickformat('%.1f');

        subplot(2,3,2)
            plot(mCP.tSol/3600, mCP.mpaDiBa_nSI, '-.', 'LineWidth', 1, 'Color', niceGruen);
            hold on;
            plot(m13.tSol/3600, m13.mpaDiBa_nSI, '--', 'LineWidth', 1, 'Color', 'b');
            plot(m0V.tSol/3600, m0V.mpaDiBa_nSI, '--', 'LineWidth', 1, 'Color', niceRed);
            plot(mCP.tSol/3600, mCP.mpaTot_nSI, '-', 'LineWidth', 1, 'Color', niceGruen);
            plot(m13.tSol/3600, m13.mpaTot_nSI, '-', 'LineWidth', 1, 'Color', 'b');
            plot(m0V.tSol/3600, m0V.mpaTot_nSI, '-', 'LineWidth', 1, 'Color', niceRed);
            h = legend('CP ba', '1.3V ba', '0 V ba', 'CP tot', '1.3V tot ', '0 V tot', 'position', [0.53 0.94 0 0], 'LineWidth', 0.5, 'NumColumns', 2, 'fontsize', 8);
            h.ItemTokenSize = [15 15];
            xlabel('Time [h]');
            ylabel('Amount Ir band & tot.[\mug/cm^2]');
            pbaspect([1 1 1]);
            box on; ax = gca; ax.LineWidth = 1;
            set(gca, 'TickLength', [0.015, 0.01]);




        subplot(2,3,4)
            plot(eCP.t_sa_nSI, eCP.mAWLperA_nSI, '*', 'LineWidth', 1, 'Color', niceGruen);
            hold on;
            plot(e13.t_sa_nSI, e13.mAWLperA_nSI, '*', 'LineWidth', 1, 'Color', 'b');
            plot(e0V.tAWL_nSI, e0V.mAWLperA_nSI, '*', 'Color', niceRed, 'LineWidth', 0.7);            
            plot(mCP.timeVec_nSI, mCP.mpaAWL_nSI, 'Color', niceGruen, 'LineWidth', 1);
            plot(m13.timeVec_nSI, m13.mpaAWL_nSI, 'Color', 'b', 'LineWidth', 1);
            plot(m0V.timeVec_nSI, m0V.mpaAWL_nSI, 'Color', niceRed, 'LineWidth', 1);
%             plot(mCP.timeVec_nSI, mCP.cIrCatAWL, '--', 'Color', niceGruen, 'LineWidth', 1);
%             plot(m13.timeVec_nSI, m13.cIrCatAWL, '-.', 'Color', 'b', 'LineWidth', 1);
            
            plot(mCP.timeVec_nSI, mCP.mpaCatAWL_nSI, '-.', 'Color', niceGruen, 'LineWidth', 1);
            plot(m13.timeVec_nSI, m13.mpaCatAWL_nSI, '-.', 'Color', 'b', 'LineWidth', 1);
            plot(m0V.timeVec_nSI, m0V.mpaCatAWL_nSI, '-.', 'Color', niceRed, 'LineWidth', 1);
%             plot(e0V.timeVec_nSI, e0V.cIrCatWL, '--', 'Color', niceRed, 'LineWidth', 1);
            plot([eCP.t_nSI_BoT, eCP.t_nSI_MoT, eCP.t_nSI_EoT], [eCP.mpaCatAWL_BoT, eCP.mpaCatAWL_MoT, eCP.mpaCatAWL_EoT], 's', 'Color', niceGruen, 'LineWidth', 1);
            plot([e13.t_nSI_BoT, e13.t_nSI_MoT, e13.t_nSI_EoT], [e13.mpaCatAWL_BoT, e13.mpaCatAWL_MoT, e13.mpaCatAWL_EoT], 's', 'Color', 'b', 'LineWidth', 1);
%             
            plot([e0V.t_nSI_BoT, e0V.t_nSI_MoT, e0V.t_nSI_EoT], [e0V.mpaCatAWL_BoT, e0V.mpaCatAWL_MoT, e0V.mpaCatAWL_EoT], 'o', 'Color', niceRed, 'LineWidth', 1, 'MarkerSize', 3);
%             plot(eCP.t_sa_nSI, mCP.mpaAWL_sa_nSI, '+', 'LineWidth', 1);       % testing picking the indices for sumOfSqCalc
            box on; ax = gca; ax.LineWidth = 1;
            set(gca, 'TickLength', [0.015, 0.01]);
            h = legend('CP', '1.3V', '0 V', 'CP', '1.3V', '0 V', 'CP (cat)', '1.3V (cat)', '0 V (cat)', 'CP (cat)', '1.3V (cat)', '0V (cat)', ...
                'Position', [0.052455 0.3 0 0], 'LineWidth', 0.5);
            h.ItemTokenSize = [15 15];
            xlabel('Time [h]');
            ylabel('Ir amount AWL. [\mug/cm^2]');
            pbaspect([1 1 1]);
            ytickformat('%.1f');

        subplot(2,3,5)
            plot(mCP.tSol/3600, mCP.mpaDiCCL_nSI, '-', 'LineWidth', 1, 'Color', niceGruen);
            hold on;
            plot(m13.tSol/3600, m13.mpaDiCCL_nSI, '-', 'LineWidth', 1, 'Color', 'b');
            plot(m0V.tSol/3600, m0V.mpaDiCCL_nSI, '-', 'LineWidth', 1, 'Color', niceRed);
            
            plot(eCP.t_CCL/3600, eCP.mPerA_nSI, '*', 'Color', niceGruen, 'LineWidth', 1);
            plot(e13.t_CCL/3600, e13.mPerA_nSI, '*', 'Color', 'b', 'LineWidth', 1);
            plot(e0V.t_CCL/3600, e0V.mPerA_nSI, '*', 'Color', niceRed, 'LineWidth', 1);
            e0V.err = [0 0.13 0.01 0.01 0.01 0.01 0.31];
            errorbar(e0V.t_CCL/3600, e0V.mPerA_nSI, e0V.err,"LineStyle","none");
            e13.err = [0 0.25];
            errorbar(e13.t_CCL/3600, e13.mPerA_nSI, e13.err, 'Color', 'b',"LineStyle","none");
            h = legend('CP', '1.3V', '0 V', 'Position', [0.57973 0.3288824 0 0], 'fontsize', 7, 'LineWidth', 0.5);
            box on; ax = gca; ax.LineWidth = 1;
            set(gca, 'TickLength', [0.015, 0.01]);
            xlabel('Time [h]');
            ylabel('Amount diss. cat. CCL [\mug/cm^2]');
            pbaspect([1 1 1]);
            h.ItemTokenSize = [15 15];
            ytickformat('%.1f');
            ylim([0, 3]);
            
        subplot(2,3,6)
            semilogy(mCP.tSol/3600, mCP.flCWL, '-', 'LineWidth', 1.5, 'Color', niceGruen);
            hold on;
            semilogy(mCP.tSol/3600, m13.flCWL, '-', 'LineWidth', 1.5, 'Color', 'b');
            semilogy(m0V.tSol/3600, m0V.flCWL, '-', 'LineWidth', 1.5, 'Color', niceRed);
            semilogy([eCP.t_nSI_BoT, eCP.t_nSI_MoT, eCP.t_nSI_EoT], [eCP.flCatCWL_BoT, eCP.flCatCWL_MoT, eCP.flCatCWL_EoT], '^', 'Color', niceGruen, 'LineWidth', 1.5);
            semilogy([e13.t_nSI_BoT, e13.t_nSI_MoT, e13.t_nSI_EoT], [e13.flCatCWL_BoT, e13.flCatCWL_MoT, e13.flCatCWL_EoT], '+', 'Color', 'b', 'LineWidth', 1.5);
            semilogy([e0V.t_nSI_BoT, e0V.t_nSI_MoT, e0V.t_nSI_EoT], [e0V.flCatCWL_BoT, e0V.flCatCWL_MoT, e0V.flCatCWL_EoT], 's', 'Color', niceRed, 'LineWidth', 1.5);
            h = legend('CP', '1.3V', '0 V', 'CP', '1.3V', '0 V', 'Position', [0.94 0.3 0 0], 'LineWidth', 0.5,'NumColumns',2);
            xlabel('Time [h]');
            ylabel('CWL cat. Ir diss. flux [mol/(m^2\cdots)]');
            pbaspect([1 1 1]);
            box on; ax = gca; ax.LineWidth = 1;
            set(gca, 'TickLength', [0.016, 0.01]);
            h.ItemTokenSize = [15 15];
            ylim([10^-14, 10^-8]);


%%
        blue = '#0040ff';
%         red = '#ff4d4d';
        red = '#cc6699';
%         green = '#99ff99';
        green = '#00cc99';
%         yellow = '#ffff99';
        yellow = '#ffff66';
%         turk    = '#00ffcc';
        turk    = '#00ccff';

        fig3 = figure('Name', 'Stacked plots');
            set(gcf, 'color', 'w');
            set(fig3, 'units', 'points', 'position', [fig.x0, fig.y0, fig.width, fig.height]);
            annotation(fig3, 'textbox', [0.227 0.72 0.03207831 0.04139130],...      % x,y
            'String', {'tot/2'}, 'LineStyle', 'none', 'FitBoxToText','off');
            annotation(fig3, 'textbox', [0.0907 0.907 0.03207831 0.04139130], 'fontsize', 12, ...      % x,y
            'String', {'a)'}, 'LineStyle', 'none', 'FitBoxToText','off');
            annotation(fig3, 'textbox', [0.373 0.907 0.03207831 0.04139130], 'fontsize', 12, ...      % x,y
            'String', {'b)'}, 'LineStyle', 'none', 'FitBoxToText','off');
            annotation(fig3, 'textbox', [0.653 0.907 0.03207831 0.04139130], 'fontsize', 12, ...      % x,y
            'String', {'c)'}, 'LineStyle', 'none', 'FitBoxToText','off');

            subplot(2,3,1);     
                mCP.stackedData1 = mCP.mpaCWL_nSI;                              % CWL
                mCP.stackedData2 = mCP.stackedData1 + mCP.mpaAWL_nSI;           % AWL+CWL
                mCP.stackedData3 = mCP.stackedData2 + mCP.mpaDiCCL_nSI;         % CCL+AWL+CWL
                mCP.stackedData4 = mCP.stackedData3 + mCP.mpaDiBa_nSI;          % band+CCL+AWL+CWL
                mCP.stackedData5 = mCP.stackedData4 + mCP.mpaBaTr_nSI;        	% backTra+band+CCL+AWL+CWL

                area(mCP.tSol/3600, mCP.stackedData5, 'FaceColor', turk); hold on;
                area(mCP.tSol/3600, mCP.stackedData4, 'FaceColor', yellow);
                area(mCP.tSol/3600, mCP.stackedData3, 'FaceColor', green); 
                area(mCP.tSol/3600, mCP.stackedData2, 'FaceColor', red);
                area(mCP.tSol/3600, mCP.stackedData1, 'FaceColor', blue);
                plot(mCP.tSol/3600, mCP.stackedData5/2, '--', 'Color', 'black', 'LineWidth', 1);

                h = legend('bt', 'band', 'CCL', 'AWL', 'CWL', 'tot/2', 'Position', [0.055 0.85 0 0], 'LineWidth', 0.5);
                h.ItemTokenSize = [15, 15];

                xlabel('Time [h]');
                ylabel('Ir amount [\mug/cm^2]');
                pbaspect([1, 1, 1]);
                title('CP');
                box on; ax = gca; ax.LineWidth = 1;
                xlim([0,175]);
                set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on', 'fontsize', 11);
                yLimits = ylim;

            subplot(2,3,2);     
                m13.stackedData1 = m13.mpaCWL_nSI;                          % 
                m13.stackedData2 = m13.stackedData1 + m13.mpaAWL_nSI;           % 
                m13.stackedData3 = m13.stackedData2 + m13.mpaDiCCL_nSI;         % 
                m13.stackedData4 = m13.stackedData3 + m13.mpaDiBa_nSI;          % 
                m13.stackedData5 = m13.stackedData4 + m13.mpaBaTr_nSI;        	% all

                area(m13.tSol/3600, m13.stackedData5, 'FaceColor', turk); hold on;
                area(m13.tSol/3600, m13.stackedData4, 'FaceColor', yellow);
                area(m13.tSol/3600, m13.stackedData3, 'FaceColor', green);
                area(m13.tSol/3600, m13.stackedData2, 'FaceColor', red);
                area(m13.tSol/3600, m13.stackedData1, 'FaceColor', blue);
            
%                 h = legend('back-Tra', 'band', 'CCL', 'AWL', 'CWL', 'Position', [0.655 0.85 0 0]);
%                 h.ItemTokenSize = [15, 15];

                xlabel('Time [h]');
                ylabel('Ir amount [\mug/cm^2]');
                pbaspect([1, 1, 1]);
                title('1.3 V');
                box on; ax = gca; ax.LineWidth = 1;
                xlim([0,175]);
                set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on', 'fontsize', 11);

            subplot(2,3,3);     
                m0V.stackedData1 = m0V.mpaCWL_nSI;
                m0V.stackedData2 = m0V.stackedData1 + m0V.mpaAWL_nSI;
                m0V.stackedData3 = m0V.stackedData2 + m0V.mpaDiCCL_nSI;
                m0V.stackedData4 = m0V.stackedData3 + m0V.mpaDiBa_nSI;         % 
                m0V.stackedData5 = m0V.stackedData4 + m0V.mpaBaTr_nSI;        	% all

                area(m0V.tSol/3600, m0V.stackedData5, 'FaceColor', turk); hold on;
                area(m0V.tSol/3600, m0V.stackedData4, 'FaceColor', yellow);
                area(m0V.tSol/3600, m0V.stackedData3, 'FaceColor', green);
                area(m0V.tSol/3600, m0V.stackedData2, 'FaceColor', red);
                area(m0V.tSol/3600, m0V.stackedData1, 'FaceColor', blue);

                h = legend('bt', 'band', 'CCL', 'AWL', 'CWL', 'Position', [0.80355 0.85 0 0], 'LineWidth', 0.5, 'numColumns', 2);
                h.ItemTokenSize = [15, 15];
                box on; ax = gca; ax.LineWidth = 1;
                xlabel('Time [h]');
                ylabel('Ir amount [\mug/cm^2]');
                pbaspect([1, 1, 1]);
                title('0 V');
%                 ylim([0, max([mCP.stackedData5; m0V.stackedData5])*1.05]);
                
                xlim([0,175]);
                set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on', 'fontsize', 11);
                % Get the ylim from subplot 3
                

            % Set the same ylim for subplot 1 and 2
            subplot(2,3,2);
                ylim(yLimits);

            subplot(2,3,3);
                ylim(yLimits);


%%

fig4 = figure('Name', 'stacked plots (CP/2 for same y-axis) + sensitivity analysis');
    set(gcf, 'color', 'w');
    set(fig4, 'units', 'points', 'position', [fig.x0, fig.y0, fig.width, fig.height]);

	subplot(2,3,1);     
        mCP.stackedData1 = mCP.mpaCWL_nSI;                              % CWL
        mCP.stackedData2 = mCP.stackedData1 + mCP.mpaAWL_nSI;           % AWL+CWL
        mCP.stackedData3 = mCP.stackedData2 + mCP.mpaDiCCL_nSI;         % CCL+AWL+CWL
        mCP.stackedData4 = mCP.stackedData3 + mCP.mpaDiBa_nSI;          % band+CCL+AWL+CWL
        mCP.stackedData5 = mCP.stackedData4 + mCP.mpaBaTr_nSI;        	% backTra+band+CCL+AWL+CWL

        area(mCP.tSol/3600, mCP.stackedData5/2, 'FaceColor', turk); hold on;
        area(mCP.tSol/3600, mCP.stackedData4/2, 'FaceColor', yellow);
        area(mCP.tSol/3600, mCP.stackedData3/2, 'FaceColor', green); 
        area(mCP.tSol/3600, mCP.stackedData2/2, 'FaceColor', red);
        area(mCP.tSol/3600, mCP.stackedData1/2, 'FaceColor', blue);

        h = legend('bt', 'band', 'CCL', 'AWL', 'CWL', 'Position', [0.055 0.85 0 0], 'LineWidth', 0.5);
        h.ItemTokenSize = [15, 15];

        xlabel('Time [h]');
        ylabel('Ir amount [\mug/cm^2]');
        pbaspect([1, 1, 1]);
        title('CP/2');
        box on; ax = gca; ax.LineWidth = 1;
        xlim([0,175]);
        set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on', 'fontsize', 11);

        ylim([0,8]);
        yLimits = ylim;

    subplot(2,3,2);     
        m13.stackedData1 = m13.mpaCWL_nSI;                          % 
        m13.stackedData2 = m13.stackedData1 + m13.mpaAWL_nSI;           % 
        m13.stackedData3 = m13.stackedData2 + m13.mpaDiCCL_nSI;         % 
        m13.stackedData4 = m13.stackedData3 + m13.mpaDiBa_nSI;          % 
        m13.stackedData5 = m13.stackedData4 + m13.mpaBaTr_nSI;        	% all

        area(m13.tSol/3600, m13.stackedData5, 'FaceColor', turk); hold on;
        area(m13.tSol/3600, m13.stackedData4, 'FaceColor', yellow);
        area(m13.tSol/3600, m13.stackedData3, 'FaceColor', green);
        area(m13.tSol/3600, m13.stackedData2, 'FaceColor', red);
        area(m13.tSol/3600, m13.stackedData1, 'FaceColor', blue);

%                 h = legend('back-Tra', 'band', 'CCL', 'AWL', 'CWL', 'Position', [0.655 0.85 0 0]);
%                 h.ItemTokenSize = [15, 15];

        xlabel('Time [h]');
        ylabel('Ir amount [\mug/cm^2]');
        pbaspect([1, 1, 1]);
        title('1.3 V');
        box on; ax = gca; ax.LineWidth = 1;
        xlim([0,175]);
        set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on', 'fontsize', 11);

    subplot(2,3,3);     
        m0V.stackedData1 = m0V.mpaCWL_nSI;
        m0V.stackedData2 = m0V.stackedData1 + m0V.mpaAWL_nSI;
        m0V.stackedData3 = m0V.stackedData2 + m0V.mpaDiCCL_nSI;
        m0V.stackedData4 = m0V.stackedData3 + m0V.mpaDiBa_nSI;         % 
        m0V.stackedData5 = m0V.stackedData4 + m0V.mpaBaTr_nSI;        	% all

        area(m0V.tSol/3600, m0V.stackedData5, 'FaceColor', turk); hold on;
        area(m0V.tSol/3600, m0V.stackedData4, 'FaceColor', yellow);
        area(m0V.tSol/3600, m0V.stackedData3, 'FaceColor', green);
        area(m0V.tSol/3600, m0V.stackedData2, 'FaceColor', red);
        area(m0V.tSol/3600, m0V.stackedData1, 'FaceColor', blue);

        h = legend('bt', 'band', 'CCL', 'AWL', 'CWL', 'Position', [0.80355 0.85 0 0], 'LineWidth', 0.5, 'numColumns', 2);
        h.ItemTokenSize = [15, 15];
        box on; ax = gca; ax.LineWidth = 1;
        xlabel('Time [h]');
        ylabel('Ir amount [\mug/cm^2]');
        pbaspect([1, 1, 1]);
        title('0 V');
%                 ylim([0, max([mCP.stackedData5; m0V.stackedData5])*1.05]);

        xlim([0,175]);
        set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on', 'fontsize', 11);
        % Get the ylim from subplot 3


    % Set the same ylim for subplot 1 and 2
    subplot(2,3,2);
        ylim(yLimits);

    subplot(2,3,3);
        ylim(yLimits);

    % 4) CP final amounts
    subplot(2,3,4); 
        cla; hold on;

        % Extract final values
        finalCWL  = mCP.mpaCWL_nSI(end);
        finalAWL  = mCP.mpaAWL_nSI(end);
        finalCCL  = mCP.mpaDiCCL_nSI(end);
        finalBand = mCP.mpaDiBa_nSI(end);
        finalBT   = mCP.mpaBaTr_nSI(end);

        % Create 2-row matrix for stacked bars:
        % Row 1 -> Original final amounts
        % Row 2 -> Halved CWL, original for the rest
        Ydata = [ ...
            0.1139         0.1587  2.7330  9.5879  0.5965; ...              % sim with default params
            finalCWL     finalAWL  finalCCL  finalBand  finalBT  ...
        ];

        % Bar centers at x = 1 and x = 2
        xpos = [1,2];

        % Plot as stacked bars
        b = bar(xpos, Ydata, 'stacked');

        % Assign face colors to match the subplots above
        b(1).FaceColor = blue;   % CWL
        b(2).FaceColor = red;    % AWL
        b(3).FaceColor = green;  % CCL
        b(4).FaceColor = yellow; % band
        b(5).FaceColor = turk;   % backTra

        % Aesthetics
        title('CP (final amounts)');
        ylabel('Ir amount [\mug/cm^2]');
        set(gca, 'XTick', xpos, 'XTickLabel', {'Default','Variation'});
        xlim([0.5, 2.5]);
        box on; ax = gca; ax.LineWidth = 1;
        pbaspect([1,1,1]);
        set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on');
        legend({'CWL','AWL','CCL','band','bt'}, 'Position', [0.055 0.35 0 0]);


    % 5) 1.3 V final amounts
    subplot(2,3,5); cla; hold on;

        % Extract final values
        finalCWL = m13.mpaCWL_nSI(end);
        finalAWL = m13.mpaAWL_nSI(end);
        finalCCL = m13.mpaDiCCL_nSI(end);
        finalBand = m13.mpaDiBa_nSI(end);
        finalBT   = m13.mpaBaTr_nSI(end);
        
        Ydata = [ ...
            0.1891         1.2098  0.6330  3.8112  1.4887; ...              % sim with default params
            finalCWL     finalAWL  finalCCL  finalBand  finalBT  ...
        ];

        % Bar centers at x = 1 and x = 2
        xpos = [1,2];

%         % Make stacked bar
%         b = bar(1, [finalCWL, finalAWL, finalCCL, finalBand, finalBT], 'stacked');
        % Plot as stacked bars
        b = bar(xpos, Ydata, 'stacked');

        % Same color ordering
        b(1).FaceColor = blue;   
        b(2).FaceColor = red;    
        b(3).FaceColor = green;  
        b(4).FaceColor = yellow; 
        b(5).FaceColor = turk;   

        title('1.3 V (final amounts)');
        ylabel('Ir amount [\mug/cm^2]');
        xlim([0.5,2.5]);
        set(gca, 'XTick', xpos, 'XTickLabel', {'Default','Variation'});
        box on; ax = gca; ax.LineWidth = 1;
        pbaspect([1,1,1]);
        set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on');

        % 6) 0 V final amounts

    subplot(2,3,6); cla; hold on;

        % Extract final values
        finalCWL = m0V.mpaCWL_nSI(end);
        finalAWL = m0V.mpaAWL_nSI(end);
        finalCCL = m0V.mpaDiCCL_nSI(end);
        finalBand = m0V.mpaDiBa_nSI(end);
        finalBT   = m0V.mpaBaTr_nSI(end);
    
        Ydata = [ ...
            0.0746         0.0964  0.8576  4.2319  2.9609; ...          % sim with default params
            finalCWL     finalAWL  finalCCL  finalBand  finalBT  ...
        ];

        % Bar centers at x = 1 and x = 2
        xpos = [1,2];

%         % Make stacked bar
%         b = bar(1, [finalCWL, finalAWL, finalCCL, finalBand, finalBT], 'stacked');
        % Plot as stacked bars
        b = bar(xpos, Ydata, 'stacked');

        % Same color ordering
        b(1).FaceColor = blue;   
        b(2).FaceColor = red;    
        b(3).FaceColor = green;  
        b(4).FaceColor = yellow; 
        b(5).FaceColor = turk;   

        title('0 V (final amounts)');
        ylabel('Ir amount [\mug/cm^2]');
        xlim([0.5,2.5]);
        set(gca, 'XTick', xpos, 'XTickLabel', {'Default','Variation'});
        box on; ax = gca; ax.LineWidth = 1;
        pbaspect([1,1,1]);
        set(gca, 'TickLength', [0.015, 0.012], 'XMinorTick', 'on');


              