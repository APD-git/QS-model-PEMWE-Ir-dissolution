function [ThBlock] = sigmo(x, mo)
% sigmoidal function
% x = amount of Ir in Ir band [mol]

    ThBlock = mo.IB_c + (1-mo.IB_c)./(   1 + exp(-mo.IB_a.*(x-mo.IB_b))   );
    
end

