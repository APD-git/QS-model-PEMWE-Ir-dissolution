%% QS-model - describing dissolution, transport and deposition of Ir species in PEMWE"
% Author: An Phuc Dam                                                                       
% E-mail: dam@mpi-magdeburg.mpg.de                                                          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%

    close all; clc; clear;
    getNatureConstants;
    
	getPar;  	% get simulation parameters
    getExp;     % get experimental data / with Ir band
    
    simCPnew    = 1;    % perform new simulation? 1=yes
    sim13new    = 1;
    sim0Vnew    = 1;
    saveSimCP   = 0;
    saveSim13   = 0;
    saveSim0V   = 0;


%% CP simulation
    
    if simCPnew == 1
        mCP.tEnd_nSI    	=   8.5;                                     	% [days]
        mCP.tEnd        	=   mCP.tEnd_nSI*24*3600;                       % [s]
        mCP.num_t_steps     =   10000;                                      % [-]
        mCP.timeVec     	=   linspace(0,mCP.tEnd, mCP.num_t_steps);   	% [s]
        mCP.timeVec_nSI 	=   mCP.timeVec/(3600);                         % [h]
        mCP.del_t           =   mCP.tEnd/mCP.num_t_steps;                   % [s]
        mCP.x_IC            =	[0, 0, 0, 0, 0, 0];                         % initial conditions

%         opts            =	odeset('Stats', 'off', 'BDF', 'off');
%         opts            =	odeset('Stats', 'off', 'BDF', 'on');
        opts            = odeset('Stats', 'off', 'BDF', 'off', 'RelTol', 1e-9, 'AbsTol', 1e-23, 'InitialStep', 1e-3, 'NormControl', 'on');

%         [mCP.tSol, mCP.xSol]    =   ode23tb(@(t, x) modelSystem(t, p, x, mCP), mCP.timeVec, mCP.x_IC, opts);
        [mCP.tSol, mCP.xSol]    =   ode23s(@(t, x) modelSystem(t, p, x, mCP), mCP.timeVec, mCP.x_IC, opts);
%         [mCP.tSol, mCP.xSol]    =   ode15s(@(t, x) modelSystem(t, p, x, mCP), mCP.timeVec, mCP.x_IC, opts);
%         [mCP.tSol, mCP.xSol]    =   ode23t(@(t, x) modelSystem(t, p, x, mCP), mCP.timeVec, mCP.x_IC, opts);

        mCP.cIrAniAWL         	=	mCP.xSol(:,1);          % [mol/m3]
        mCP.nDiCCL           	=   mCP.xSol(:,2);          % [mol]
        mCP.nDiBa               =   mCP.xSol(:,3);          % [mol]
        mCP.nBackTr            	=   mCP.xSol(:,4);          % [mol]
        mCP.nCWL                =   mCP.xSol(:,5);          % [mol]
        mCP.cIrCatAWL         	=	mCP.xSol(:,6);          % [mol/m3]

        for i=1:length(mCP.timeVec_nSI)
            [mCP.diRateAniAWL(i,1), mCP.diRateCatAWL(i,1), mCP.diRateCatIP(i,1), mCP.R_bf(i,1), mCP.ThBl(i,1),	...
                mCP.RbackTrAni(i,1), mCP.RbackTrCat(i,1), mCP.F_CWL(i,1), mCP.FtoCath(i,1), mCP.RdepCCL(i,1), mCP.FconvAni(i,1), mCP.lp(i,1)]	...
                = getRates(mCP.tSol(i,1), p, mCP.nDiBa(i,1), mCP.cIrAniAWL(i,1), mCP.cIrCatAWL(i,1), mCP);
        end

        mCP.cIrAWL            	= mCP.cIrAniAWL + mCP.cIrCatAWL;     	% [mol/m3]
        mCP.diRateAniAWLPerA   	= mCP.diRateAniAWL/p.A;              	% [mol/(m2*s)]
        mCP.diRateCatAWLPerA   	= mCP.diRateCatAWL/p.A;               	% [mol/(m2*s)]
        mCP.diRateCatIPPerA     = mCP.diRateCatIP/p.A;               	% [mol/(m2*s)]
        mCP.flCWL               = mCP.F_CWL/p.A;                        % [mol/(m2*s)]

        mCP.flBackTrAni         = mCP.RbackTrAni/p.A;                   % [mol/(m2*s)]
        mCP.flBackTrCat         = mCP.RbackTrCat/p.A;                   % [mol/(m2*s)]
        mCP.flBackTrTot         = mCP.flBackTrAni + mCP.flBackTrCat;    % [mol/(m2*s)]

        mCP.diRatePerA          = mCP.diRateCatIPPerA + mCP.diRateAniAWLPerA + mCP.diRateCatAWLPerA;        % [mol/(m2*s)]

        mCP.S_N                 = p.nDotO2perA./mCP.diRatePerA;                     % automatically "during on" in CP-case 
        mCP.diRateCatAWLPerA   	= mCP.diRateCatAWL/p.A;                          	% [mol/(m2*s)]
        mCP.diRateAWLPerA      	= mCP.diRateCatAWLPerA + mCP.diRateAniAWLPerA;      % [mol/(m2*s)]

        mCP.mpaDiCCL_nSI 	= mol_ugPerCm2(mCP.nDiCCL, p);
        mCP.mpaBaTr_nSI 	= mol_ugPerCm2(mCP.nBackTr, p);                     % [ug/cm2] "mpa" = mass per area
        mCP.mpaCWL_nSI      = mol_ugPerCm2(mCP.nCWL, p);                        % [ug/cm2]
        mCP.mpaDiBa_nSI   	= mol_ugPerCm2(mCP.nDiBa, p);                       % [ug/cm2]
        mCP.mpaAWL_nSI      = mol_ugPerCm2(mCP.cIrAWL*p.V, p);                  % [ug/cm2]
        mCP.mpaCatAWL_nSI 	= mol_ugPerCm2(mCP.cIrCatAWL*p.V, p);               % [ug/cm2]

        mCP.mpaTot_nSI      = mCP.mpaDiCCL_nSI + mCP.mpaBaTr_nSI + mCP.mpaCWL_nSI + mCP.mpaDiBa_nSI + mCP.mpaAWL_nSI;   % [ug/cm2]

        mCP.mpaTot          = mCP.mpaTot_nSI*(10^-9)*10000;             % [kg/m2]
        mCP.npaTot          = mCP.mpaTot/p.M_Ir;                        % [mol/m2]
        mCP.nO2_PerA        = p.nDotO2perA*mCP.timeVec';                % [mol/m2]         
        mCP.S_N_acc         = mCP.nO2_PerA./mCP.npaTot;                 % [-]

        mCP.molDiBaVec     	= linspace(0,2E-6,100);                     % [mol] vector for plotting
        mCP.mpaDiBaVec_nSI 	= mol_ugPerCm2(mCP.molDiBaVec, p);          % [ug/cm2]
        mCP.ThBlTheo      	= sigmo(mCP.molDiBaVec, mCP);               % [mol]
    else
        load simDataCP_2;
        disp('*** Simulation data CP loaded ***');
    end
    
    mCP.diRateAWL           = mCP.diRateCatAWL + mCP.diRateAniAWL;   	% [mol/s]
    mCP.F_IrAWL             = mCP.cIrAWL*VdotH2O;                     	% [mol/s]
    mCP.Ratio_FoverRecirc   = mCP.diRateAWL./mCP.F_IrAWL;               % [-]

%% AST 1.3V simulation
    
    if sim13new==1
        m13.tEnd_nSI    	=   8.5;                                        % [days] 
        m13.tEnd        	=   m13.tEnd_nSI*24*3600;                       % [s] 
        m13.num_t_steps     =   10000;                                      % [-]
        m13.timeVec     	=   linspace(0,m13.tEnd, m13.num_t_steps);   	% [s]
        m13.timeVec_nSI 	=   m13.timeVec/(3600);                         % [h]
        m13.del_t           =   m13.tEnd/m13.num_t_steps;                   % [s]
        m13.x_IC         	=   [0,0,0, 0, 0, 0];                           % initial conditions

%         opts                    =	odeset('Stats', 'off', 'BDF', 'on');
        opts            = odeset('Stats', 'off', 'BDF', 'off', 'RelTol', 1e-9, 'AbsTol', 1e-23, 'InitialStep',1e-3, 'NormControl','on');
%         [m13.tSol, m13.xSol]    =   ode23tb(@(t, x) modelSystem(t, p, x, m13), m13.timeVec, m13.x_IC, opts);
        [m13.tSol, m13.xSol]    =   ode23s(@(t, x) modelSystem(t, p, x, m13), m13.timeVec, m13.x_IC, opts);

        m13.cIrAniAWL        	=   m13.xSol(:,1);        % [mol/m3]
        m13.nDiCCL           	=   m13.xSol(:,2);        % [mol]
        m13.nDiBa               =   m13.xSol(:,3);        % [mol]
        m13.nBackTr            	= 	m13.xSol(:,4);        % [mol]
        m13.nCWL                =	m13.xSol(:,5);        % [mol]
        m13.cIrCatAWL        	=   m13.xSol(:,6);        % [mol/m3]

        for i=1:length(m13.timeVec_nSI)
            [m13.diRateAniAWL(i,1), m13.diRateCatAWL(i,1), m13.diRateCatIP(i,1), m13.R_bf(i,1), m13.ThBl(i,1), ...
                m13.RbackTrAni(i,1), m13.RbackTrCat(i,1), m13.F_CWL(i,1), m13.FtoCath(i,1), m13.RdepCCL(i,1), m13.FconvAni(i,1)] ...
                = getRates(m13.tSol(i,1), p, m13.nDiBa(i,1), m13.cIrAniAWL(i,1), m13.cIrCatAWL(i,1), m13);
        end

        m13.cIrAWL            	= m13.cIrAniAWL + m13.cIrCatAWL;                                        % [mol/m3]
        m13.diRateAniAWLPerA  	= m13.diRateAniAWL/p.A;                                              	% [mol/(m2*s)]
        m13.diRateCatAWLPerA  	= m13.diRateCatAWL/p.A;                                             	% [mol/(m2*s)]
        m13.diRateCatIPPerA     = m13.diRateCatIP/p.A;                                                  % [mol/(m2*s)]
        m13.diRatePerA          = m13.diRateCatIPPerA + m13.diRateAniAWLPerA + m13.diRateCatAWLPerA;   	% [mol/(m2*s)]
        m13.S_N                 = p.nDotO2perA./(2*m13.diRatePerA);                                   	% [-] S_N is the same for "on-phase only" and "average" div2 since actual OER time was lower!
        m13.flCWL               = m13.F_CWL/p.A;
        
        m13.flBackTrAni         = m13.RbackTrAni/p.A;                           % [mol/(m2*s)]
        m13.flBackTrCat         = m13.RbackTrCat/p.A;                           % [mol/(m2*s)]
        m13.flBackTrTot         = m13.flBackTrAni + m13.flBackTrCat;            % [mol/(m2*s)]

        m13.diRateCatAWLPerA 	= m13.diRateCatAWL/p.A;                                                % [mol/(m2*s)]
        m13.diRateAWLPerA     	= m13.diRateCatAWLPerA + m13.diRateAniAWLPerA;                         % [mol/(m2*s)]

%         note.S_N13          = 'attention: Factor 0.5 for S_N calc. of 1.3V used';

        m13.mpaDiCCL_nSI    = mol_ugPerCm2(m13.nDiCCL, p);
        m13.mpaBaTr_nSI 	= mol_ugPerCm2(m13.nBackTr, p);                     % [ug/cm2] "mpa" = mass per area
        m13.mpaCWL_nSI      = mol_ugPerCm2(m13.nCWL, p);                        % [ug/cm2] 
        m13.mpaDiBa_nSI    	= mol_ugPerCm2(m13.nDiBa, p);                       % [ug/cm2] 
        m13.mpaAWL_nSI      = mol_ugPerCm2(m13.cIrAWL*p.V, p);                  % [ug/cm2] 
        m13.mpaCatAWL_nSI 	= mol_ugPerCm2(m13.cIrCatAWL*p.V, p);               % [ug/cm2] 
        m13.mpaTot_nSI      = m13.mpaDiCCL_nSI + m13.mpaBaTr_nSI + m13.mpaCWL_nSI + m13.mpaDiBa_nSI + m13.mpaAWL_nSI;

        m13.mpaTot          = m13.mpaTot_nSI*(10^-9)*10000;     % [kg/m2]
        m13.npaTot          = m13.mpaTot/p.M_Ir;                % [mol/m2]
        m13.nO2_PerA        = p.nDotO2perA*m13.timeVec'/2;    	% [mol/m2]    /2 due to off phases     
        m13.S_N_acc         = m13.nO2_PerA./m13.npaTot;         % [-]
        
        m13.molDiBaVec      = linspace(0,2E-6,100);                 % [mol]
        m13.mpaDiBaVec_nSI	= mol_ugPerCm2(m13.molDiBaVec, p);      % [ug/cm2] 
        m13.ThBlTheo        = sigmo(m13.molDiBaVec, m13);           % [-]
    else
        load simData13_2;
        disp('*** Simulation data 1.3 V loaded ***');
    end   
    
    m13.diRateAWL           = m13.diRateCatAWL + m13.diRateAniAWL;    	% [mol/s]
    m13.F_IrAWL             = m13.cIrAWL*VdotH2O;                   	% [mol/s]
    m13.Ratio_FoverRecirc   = m13.diRateAWL./m13.F_IrAWL;               % [-]

%% AST 0 V simulation
    
    if sim0Vnew==1
        m0V.tEnd_nSI    	=   8.5;                                      	% [days] 
        m0V.tEnd        	=   m0V.tEnd_nSI*24*3600;                    	% [s]   
        m0V.num_t_steps     =	10000;                                      % [-]
        m0V.timeVec     	=   linspace(0,m0V.tEnd, m0V.num_t_steps);   	% [s]
        m0V.timeVec_nSI 	=   m0V.timeVec/(3600);                         % [h]
        m0V.del_t           =   m0V.tEnd/m0V.num_t_steps;                   % [s]
        m0V.x_IC         	=   [0, 0, 0, 0, 0, 0];                         % initial conditions

%         opts                    =	odeset('Stats', 'off', 'BDF', 'on');
        opts            = odeset('Stats', 'off', 'BDF', 'off', 'RelTol', 1e-9, 'AbsTol', 1e-23, 'InitialStep',1e-3, 'NormControl','on');
%         [m0V.tSol, m0V.xSol]    =   ode23tb(@(t, x) modelSystem(t, p, x, m0V), m0V.timeVec, m0V.x_IC, opts);
        [m0V.tSol, m0V.xSol]    =   ode23s(@(t, x) modelSystem(t, p, x, m0V), m0V.timeVec, m0V.x_IC, opts);

        m0V.cIrAniAWL        	=   m0V.xSol(:,1);        % [mol/m3]
        m0V.nDiCCL           	=   m0V.xSol(:,2);        % [mol]
        m0V.nDiBa               =   m0V.xSol(:,3);        % [mol]
        m0V.nBackTr            	= 	m0V.xSol(:,4);        % [mol]
        m0V.nCWL                =	m0V.xSol(:,5);        % [mol]
        m0V.cIrCatAWL        	=   m0V.xSol(:,6);        % [mol/m3]

        for i=1:length(m0V.timeVec_nSI)
            [m0V.diRateAniAWL(i,1), m0V.diRateCatAWL(i,1), m0V.diRateCatIP(i,1), m0V.R_bf(i,1), m0V.ThBl(i,1), ...
                m0V.RbackTrAni(i,1), m0V.RbackTrCat(i,1), m0V.F_CWL(i,1), m0V.FtoCath(i,1), m0V.RdepCCL(i,1), m0V.FconvAni(i,1)] ...
                = getRates(m0V.tSol(i,1), p, m0V.nDiBa(i,1), m0V.cIrAniAWL(i,1), m0V.cIrCatAWL(i,1), m0V);
        end

        m0V.flBackTrAni         = m0V.RbackTrAni/p.A;                   % [mol/(m2*s)]
        m0V.flBackTrCat         = m0V.RbackTrCat/p.A;                   % [mol/(m2*s)]
        m0V.flBackTrTot         = m0V.flBackTrAni + m0V.flBackTrCat;    % [mol/(m2*s)]

        m0V.cIrAWL            	= m0V.cIrAniAWL + m0V.cIrCatAWL;                                        % [mol/m3]
        m0V.diRateAniAWLPerA  	= m0V.diRateAniAWL/p.A;                                              	% [mol/(m2*s)]
        m0V.diRateCatAWLPerA   	= m0V.diRateCatAWL/p.A;                                             	% [mol/(m2*s)]
        m0V.diRateCatIPPerA     = m0V.diRateCatIP/p.A;                                                  % [mol/(m2*s)]
        m0V.diRatePerA          = m0V.diRateCatIPPerA + m0V.diRateAniAWLPerA + m0V.diRateCatAWLPerA;   	% [mol/(m2*s)]
        m0V.S_N                 = p.nDotO2perA./(2*m0V.diRatePerA);                                  	% [-] S_N is the same for "on-phase only" and "average"
        m0V.flCWL               = m0V.F_CWL/p.A;

        m0V.diRateCatAWLPerA     = m0V.diRateCatAWL/p.A;                                                % [mol/(m2*s)]
        m0V.diRateAWLPerA        = m0V.diRateCatAWLPerA + m0V.diRateAniAWLPerA;                         % [mol/(m2*s)]

%         note.S_N0V          = 'attention: Factor 0.5 for S_N calc. of 1.3V used';

        m0V.mpaDiCCL_nSI    = mol_ugPerCm2(m0V.nDiCCL, p);          % [ug/cm2] "mpa": mass per area
        m0V.mpaBaTr_nSI 	= mol_ugPerCm2(m0V.nBackTr, p);     	% [ug/cm2]
        m0V.mpaCWL_nSI      = mol_ugPerCm2(m0V.nCWL, p);        	% [ug/cm2] 
        m0V.mpaDiBa_nSI    	= mol_ugPerCm2(m0V.nDiBa, p);           % [ug/cm2] 
        m0V.mpaAWL_nSI      = mol_ugPerCm2(m0V.cIrAWL*p.V, p);      % [ug/cm2]
        m0V.mpaCatAWL_nSI 	= mol_ugPerCm2(m0V.cIrCatAWL*p.V, p);   % [ug/cm2]
        m0V.mpaTot_nSI      = m0V.mpaDiCCL_nSI + m0V.mpaBaTr_nSI + m0V.mpaCWL_nSI + m0V.mpaDiBa_nSI + m0V.mpaAWL_nSI; 
    
        m0V.mpaTot          = m0V.mpaTot_nSI*(10^-9)*10000;     % [kg/m2]
        m0V.npaTot          = m0V.mpaTot/p.M_Ir;                % [mol/m2]
        m0V.nO2_PerA        = p.nDotO2perA*m0V.timeVec'/2;    	% [mol/m2]    /2 due to off-phases     
        m0V.S_N_acc         = m0V.nO2_PerA./m0V.npaTot;         % [-]

        m0V.molDiBaVec      = linspace(0,2E-6,100);                     % [mol]
        m0V.mpaDiBaVec_nSI	= mol_ugPerCm2(m0V.molDiBaVec, p);          % [ug/cm2]      
        m0V.ThBlTheo        = sigmo(m0V.molDiBaVec, m0V);               % [-]
    else  
        load simData0V_2;
        disp('*** Simulation data 0 V loaded ***');
    end   

    m0V.diRateAWL           = m0V.diRateCatAWL + m0V.diRateAniAWL;          % [mol/s]
    m0V.F_IrAWL             = m0V.cIrAWL*VdotH2O;                           % [mol/s]
    m0V.Ratio_FoverRecirc   = m0V.diRateAWL./m0V.F_IrAWL;                   % [-]


%% plotting and display

    v_conv      = (p.cd/(1*p.F))*p.nDrag*(p.M_H2O/p.rho_H2O);       % convection velocity

    showFigs;
    dispNotes;

%% save simulation data

    if saveSimCP==1
        if simNo==1
            save('simDataCP_1.mat', 'mCP');
            disp('*** Simulation data CP saved ***');
        end
        if simNo==2
            save('simDataCP_2.mat', 'mCP');
            disp('*** Simulation data CP saved ***');
        end
        if simNo==3
            save('simDataCP_3.mat', 'mCP');
            disp('*** Simulation data CP saved ***');
        end
    end

    if saveSim13==1
        if simNo==1
            save('simData13_1.mat', 'm13');
            disp('*** Simulation data 1.3 V saved ***');
        end
        if simNo==2
            save('simData13_2.mat', 'm13');
            disp('*** Simulation data 1.3 V saved ***');
        end
        if simNo==3
            save('simData13_3.mat', 'm13');
            disp('*** Simulation data 1.3 V saved ***');
        end
    end

    if saveSim0V==1
        if simNo==1
            save('simData0V_1.mat', 'm0V');
            disp('*** Simulation data 0 V saved ***');
        end
        if simNo==2
            save('simData0V_2.mat', 'm0V');
            disp('*** Simulation data 0 V saved ***');
        end
        if simNo==3
            save('simData0V_3.mat', 'm0V');
            disp('*** Simulation data 0 V saved ***');
        end
    end


